// IIFE

(() => {
	let main = document.querySelector('main');
	div = document.createElement('div');
	main.appendChild(div);
	div.addEventListener('mouseenter', mouseEventHandle);
})();

function mouseEventHandle() {
	console.log('trigger');
}
